//
//  PennyWiseTests.swift
//  PennyWiseTests
//
//  Created by Kritika Mehra on 04/10/25.
//

import Testing
@testable import PennyWise

struct PennyWiseTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
